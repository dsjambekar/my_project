export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyA7Oy_CIKv4VpRcyRaz8bzz6Lu_ernhYXQ",
    authDomain: "project1-1b168.firebaseapp.com",
    databaseURL: "https://project1-1b168.firebaseio.com",
    projectId: "project1-1b168",
    storageBucket: "project1-1b168.appspot.com",
    messagingSenderId: "559209906236"
  }
};
