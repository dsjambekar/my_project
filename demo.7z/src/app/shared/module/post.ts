export class Post{

}