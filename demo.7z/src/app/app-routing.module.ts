import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PostsContainerComponent } from "./posts-container/posts-container.component";
import { RepositoryComponent } from "./repository/repository.component";
import { PageNotFoundComponent } from "./page-not-found/page-not-found.component";

const appRoutes: Routes = [
    { path: 'blog', component: PostsContainerComponent }
    ,{ path: 'repository', component: RepositoryComponent }
    ,{ path: '',   redirectTo: '/blog', pathMatch: 'full' }
    ,{ path: '**', component: PageNotFoundComponent }
  ];

  
@NgModule({
    imports: [
      RouterModule.forRoot(
        appRoutes,
        { enableTracing: true } // <-- debugging purposes only
      )
    ],
    exports: [
      RouterModule
    ]
  })
export class AppRoutingModule {}

