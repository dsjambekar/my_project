import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { RepositoryComponent } from './repository/repository.component';
import { LoginComponent } from './login/login.component';
import { PostsContainerComponent } from './posts-container/posts-container.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { environment } from '../environments/environment.prod';


@NgModule({
  declarations: [
    AppComponent,
    PostsContainerComponent,
    RepositoryComponent,
    LoginComponent,
    PageNotFoundComponent,
  ],
  imports: [
    BrowserModule
    ,AppRoutingModule
    ,AngularFireModule.initializeApp( environment.firebase),
    AngularFireDatabaseModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
